// デバッグフラグ
//#define DEBUG

// DB接続情報
#define SERVER "localhost"
#define USER "kamimine"
#define PASSWORD "kamimine01"
#define DATABASE "kamimine_db"
#define portNo 3306
#define PI 3.14159265358979

// アプリケーション用
#define BUSCOMPANY_ID "KMM"
